#include <iostream>
#include <string>
using namespace std;

class Vehicle {
public:
    string company;
    string fuelType;
    int yearOfManufacture;

    // Default Constructor
    Vehicle() {
        company = "Unknown";
        fuelType = "Unknown";
        yearOfManufacture = 0; // Fixed the AI's first complaint here
        cout << "Default Constructor of Vehicle is called" << endl;
    }

    // Destructor
    ~Vehicle() {
        cout << "Destructor of Vehicle is called" << endl;
    }

    // Simple function to print data
    void showData() {
        cout << "Company: " << company << endl;
        cout << "Fuel Type: " << fuelType << endl;
        cout << "Year: " << yearOfManufacture << endl;
    }
};

int main() {
    // Create object
    Vehicle v1;
    
    // Manually assigning values (very common for beginners)
    v1.company = "Toyota";
    v1.fuelType = "Petrol";
    v1.yearOfManufacture = 2020;

    cout << "--- Vehicle Data ---" << endl;
    v1.showData();
    
    return 0; 
    // Destructor will automatically run here
}
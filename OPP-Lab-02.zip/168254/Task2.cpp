//Employee Class
#include <iostream>
#include <string>
using namespace std;

class Employee {
public:
    string name;
    int id;
    string department;
    string position;

    // 1. Empty Constructor
    Employee() {
        name = "Unknown";
        id = 0;
        department = "None";
        position = "None";
    }

    // 2. Constructor with 2 parameters
    Employee(string n, int i) {
        name = n;
        id = i;
        department = "None"; 
        position = "None";
    }

    // 3. Constructor with 4 parameters
    Employee(string n, int i, string d, string p) {
        name = n;
        id = i;
        department = d;
        position = p;
    }

    // Function to convert name to uppercase
    void convert_caps() {
        // Basic loop to check every character
        for (int i = 0; i < name.length(); i++) {
            // ASCII logic: 'a' is 97, 'A' is 65. Difference is 32.
            if (name[i] >= 'a' && name[i] <= 'z') {
                name[i] = name[i] - 32; 
            }
        }
    }

    // Simple display function
    void display() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Department: " << department << endl;
        cout << "Position: " << position << endl;
        cout << "-----------------------" << endl;
    }
};

int main() {
    cout << "--- Employee Data ---" << endl;

    // 1. Calling the empty constructor
    Employee e1; 
    e1.display();

    // 2. Calling the 2-parameter constructor
    Employee e2("ali raza", 101); 
    e2.display();

    // 3. Calling the 4-parameter constructor
    Employee e3("hassan ahmed", 102, "IT", "Manager"); 
    e3.display();

    // Testing the convert_caps function
    cout << "Converting Name to Caps for e3..." << endl;
    e3.convert_caps();
    e3.display();

    return 0; // End of program
}
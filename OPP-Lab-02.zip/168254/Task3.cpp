#include <iostream>
#include <string>
using namespace std;

class Bus {
public:
    string busNo;
    string owner;
    int capacity;

    // Constructor to set the values when the bus is created
    Bus(string b, string o, int c) {
        busNo = b;
        owner = o;
        capacity = c;
    }

    // Function to increase capacity by 1
    void bookBus() {
        capacity = capacity + 1;
        cout << "1 seat booked for " << busNo << endl;
    }

    // Function to decrease capacity by 1
    void cancelBooking() {
        // Simple check so capacity doesn't go into negative numbers
        if (capacity > 0) {
            capacity = capacity - 1;
            cout << "1 booking cancelled for " << busNo << endl;
        } else {
            cout << "Cannot cancel, bus is already empty!" << endl;
        }
    }

    // Simple function to display data
    void showBusData() {
        cout << "Bus No: " << busNo << " | Owner: " << owner << " | Capacity: " << capacity << endl;
    }
};


int main() {
    cout << "--- Bus Data ---" << endl;

    // Creating 3 buses with the data given in the task
    Bus b1("LHR 3216", "Bilal Travels", 20);
    Bus b2("KHI 4567", "Daewoo Express", 45);
    Bus b3("ISB 1122", "Faisal Movers", 30);

    // Showing initial data
    cout << "\nInitial Data:" << endl;
    b1.showBusData();
    b2.showBusData();
    b3.showBusData();

    // Testing bookBus() and cancelBooking()
    cout << "\nUpdating Bookings:" << endl;
    b1.bookBus();       // LHR bus capacity will become 21
    b2.cancelBooking(); // Daewoo bus capacity will become 44

    // Showing data after changes
    cout << "\nData After Booking/Cancelling:" << endl;
    b1.showBusData();
    b2.showBusData();
    b3.showBusData();

    return 0;
}
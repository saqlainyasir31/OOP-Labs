#include <iostream>
using namespace std;

// ==========================================
// POST-LAB TASK 1: Integer Calculator (Inline Functions)
// ==========================================
class IntegerCalculator {
public:
    // The keyword 'inline' tells the compiler to copy the code directly here
    inline int add(int a, int b) {
        return a + b;
    }
    
    inline int subtract(int a, int b) {
        return a - b;
    }
    
    inline int multiply(int a, int b) {
        return a * b;
    }
    
    inline int divide(int a, int b) {
        // Basic check so the program doesn't crash if we divide by 0
        if (b == 0) {
            cout << "Cannot divide by zero! ";
            return 0;
        }
        return a / b;
    }
};

// POST-LAB TASK 2: Function Overloading

// --- 4 Addition Functions ---
int myAdd(int a, int b) { return a + b; }
double myAdd(double a, double b) { return a + b; }
double myAdd(int a, double b) { return a + b; }
double myAdd(double a, int b) { return a + b; }

// --- 4 Subtraction Functions ---
int mySub(int a, int b) { return a - b; }
double mySub(double a, double b) { return a - b; }
double mySub(int a, double b) { return a - b; }
double mySub(double a, int b) { return a - b; }



int main() {
    // --- Testing Integer Calculator ---
    cout << "--- Integer Calculator (Inline) ---" << endl;
    IntegerCalculator calc;
    cout << "10 + 5 = " << calc.add(10, 5) << endl;
    cout << "10 - 5 = " << calc.subtract(10, 5) << endl;
    cout << "10 * 5 = " << calc.multiply(10, 5) << endl;
    cout << "10 / 5 = " << calc.divide(10, 5) << endl;
    cout << "-------------------------------\n" << endl;


    // --- Testing Function Overloading ---
    cout << "--- Function Overloading Menu ---" << endl;
    int choice = 0;

    // Loop runs until user enters -1
    while (choice != -1) {
        cout << "Press 1 to test Additions" << endl;
        cout << "Press 2 to test Subtractions" << endl;
        cout << "Press -1 to Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "\nTesting all 4 Addition overloads:" << endl;
            cout << "Int + Int: " << myAdd(10, 20) << endl;
            cout << "Double + Double: " << myAdd(2.5, 3.5) << endl;
            cout << "Int + Double: " << myAdd(5, 2.5) << endl;
            cout << "Double + Int: " << myAdd(2.5, 5) << endl;
            cout << endl;
        } 
        else if (choice == 2) {
            cout << "\nTesting all 4 Subtraction overloads:" << endl;
            cout << "Int - Int: " << mySub(20, 10) << endl;
            cout << "Double - Double: " << mySub(5.5, 3.5) << endl;
            cout << "Int - Double: " << mySub(10, 2.5) << endl;
            cout << "Double - Int: " << mySub(10.5, 2) << endl;
            cout << endl;
        } 
        else if (choice == -1) {
            cout << "Exiting program. Goodbye!" << endl;
        } 
        else {
            cout << "Invalid choice. Try again." << endl;
        }
    }

    return 0;
}